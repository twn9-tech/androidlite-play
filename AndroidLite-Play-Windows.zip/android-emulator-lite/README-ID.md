# AndroidLite Play untuk Windows

Paket ini membuat emulator Android mandiri dengan Google Play Store menggunakan Android SDK resmi.

Konfigurasi yang dipakai:

- RAM emulator: 3072 MB
- CPU virtual: 2 core
- Resolusi: 1280×720
- Image: Android 35 Google Play x86_64
- Penyimpanan data: sekitar 4 GB awal dan dapat membesar

## Persyaratan

- Windows 10 atau Windows 11 64-bit.
- RAM PC 8 GB atau lebih.
- Virtualisasi CPU aktif di BIOS/UEFI: Intel VT-x atau AMD-V/SVM.
- Koneksi internet saat pemasangan pertama.
- `winget` tersedia. Biasanya sudah ada pada Windows 10/11 terbaru melalui App Installer.

## Cara memasang

1. Ekstrak folder ini ke lokasi yang mudah ditemukan.
2. Klik kanan `Buat-Emulator-Play.ps1`, pilih **Run with PowerShell**. Jika Windows menolak skrip, buka PowerShell sebagai Administrator dan jalankan:

   ```powershell
   Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
   ```

3. Jalankan kembali `Buat-Emulator-Play.ps1`.
4. Tunggu Android Studio/SDK dan image Google Play selesai diunduh. Ukurannya beberapa GB.
5. Setelah selesai, buka `Mulai-Emulator.bat`.

## Penggunaan

- Masuk ke akun Google di Play Store seperti pada HP biasa.
- HP fisik tidak perlu tersambung.
- Untuk mematikan emulator, buka `Matikan-Emulator.bat` atau tutup jendela emulator.
- Aplikasi APK dapat dipasang dengan drag-and-drop ke jendela emulator.

## Catatan

Paket ini membuat emulator Android baru, bukan menyalin ROM HP secara utuh. Foto dan dokumen dapat dipindahkan manual, sedangkan sebagian besar aplikasi harus dipasang ulang dan login kembali. Aplikasi bank atau game tertentu dapat menolak berjalan di emulator.

Jika emulator terasa lambat, tutup aplikasi Windows lain dan pastikan virtualisasi CPU aktif. Jangan menaikkan RAM emulator di atas 4096 MB pada PC dengan RAM 8 GB.
