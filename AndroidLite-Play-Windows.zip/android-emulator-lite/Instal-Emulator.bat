@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Buat-Emulator-Play.ps1"
pause
