#requires -Version 5.1
[CmdletBinding()]
param(
    [switch]$InstallOnly,
    [switch]$Start
)

$ErrorActionPreference = 'Stop'
$AvdName = 'AndroidLite-Play'
$SdkRoot = if ($env:ANDROID_HOME) { $env:ANDROID_HOME } elseif ($env:ANDROID_SDK_ROOT) { $env:ANDROID_SDK_ROOT } else { Join-Path $env:LOCALAPPDATA 'Android\Sdk' }
$EmulatorDir = Join-Path $SdkRoot 'emulator'
$PlatformToolsDir = Join-Path $SdkRoot 'platform-tools'
$CmdlineTools = Join-Path $SdkRoot 'cmdline-tools\latest\bin'
$SdkManager = Join-Path $CmdlineTools 'sdkmanager.bat'
$AvdManager = Join-Path $CmdlineTools 'avdmanager.bat'
$EmulatorExe = Join-Path $EmulatorDir 'emulator.exe'
$AdbExe = Join-Path $PlatformToolsDir 'adb.exe'

function Info($text) { Write-Host "[INFO] $text" -ForegroundColor Cyan }
function Warn($text) { Write-Host "[PERINGATAN] $text" -ForegroundColor Yellow }
function Fail($text) { Write-Host "[GAGAL] $text" -ForegroundColor Red; exit 1 }

Write-Host ''
Write-Host '=== AndroidLite Play untuk Windows ===' -ForegroundColor Green
Write-Host "AVD: $AvdName | RAM: 3072 MB | CPU: 2 core | Google Play: aktif" -ForegroundColor Gray
Write-Host ''

if (-not (Test-Path $SdkManager)) {
    # Android Studio kadang memasang SDK di lokasi pengguna lain atau tanpa folder latest.
    $candidates = @(
        (Join-Path $env:LOCALAPPDATA 'Android\Sdk\cmdline-tools\latest\bin\sdkmanager.bat'),
        (Join-Path $env:LOCALAPPDATA 'Android\Sdk\cmdline-tools\bin\sdkmanager.bat'),
        (Join-Path $env:ProgramFiles 'Android\Android Studio\cmdline-tools\latest\bin\sdkmanager.bat'),
        (Join-Path ${env:ProgramFiles(x86)} 'Android\Android Studio\cmdline-tools\latest\bin\sdkmanager.bat')
    )
    foreach ($candidate in $candidates) {
        if (Test-Path $candidate) { $SdkManager = $candidate; break }
    }
}

if (-not (Test-Path $SdkManager)) {
    Info 'Command-line tools belum tersedia. Mengunduh paket resmi Google...'
    $toolsRoot = Join-Path $SdkRoot 'cmdline-tools'
    $toolsZip = Join-Path $env:TEMP 'android-commandlinetools.zip'
    $toolsUrl = 'https://dl.google.com/android/repository/commandlinetools-win-11076708_latest.zip'
    New-Item -ItemType Directory -Force -Path $toolsRoot | Out-Null
    Invoke-WebRequest -Uri $toolsUrl -OutFile $toolsZip -UseBasicParsing
    $unpack = Join-Path $env:TEMP 'android-commandlinetools-unpack'
    if (Test-Path $unpack) { Remove-Item $unpack -Recurse -Force }
    Expand-Archive -Path $toolsZip -DestinationPath $unpack -Force
    $latest = Join-Path $toolsRoot 'latest'
    if (Test-Path $latest) { Remove-Item $latest -Recurse -Force }
    Move-Item (Join-Path $unpack 'cmdline-tools') $latest
    $SdkManager = Join-Path $latest 'bin\sdkmanager.bat'
    if (-not (Test-Path $SdkManager)) { Fail 'Command-line tools gagal diunduh. Periksa koneksi internet lalu jalankan lagi.' }
}

$SdkRoot = ($SdkManager -replace '\\cmdline-tools\\.*$', '')
$EmulatorExe = Join-Path $SdkRoot 'emulator\emulator.exe'
$AdbExe = Join-Path $SdkRoot 'platform-tools\adb.exe'
$AvdManager = Join-Path (Split-Path $SdkManager -Parent) 'avdmanager.bat'
$javaCandidates = @(
    (Join-Path $env:ProgramFiles 'Android\Android Studio\jbr\bin\java.exe'),
    (Join-Path ${env:ProgramFiles(x86)} 'Android\Android Studio\jbr\bin\java.exe'),
    (Join-Path $env:LOCALAPPDATA 'Programs\Android Studio\jbr\bin\java.exe')
)
if ($env:JAVA_HOME) { $javaCandidates = @((Join-Path $env:JAVA_HOME 'bin\java.exe')) + $javaCandidates }
if (-not (Get-Command java.exe -ErrorAction SilentlyContinue)) {
    foreach ($java in $javaCandidates) {
        if ($java -and (Test-Path $java)) {
            $env:JAVA_HOME = Split-Path (Split-Path $java -Parent) -Parent
            $env:Path = (Join-Path $env:JAVA_HOME 'bin') + ';' + $env:Path
            Info "Menggunakan Java bawaan Android Studio: $env:JAVA_HOME"
            break
        }
    }
}
if (-not (Get-Command java.exe -ErrorAction SilentlyContinue)) {
    $searchRoots = @(
        (Join-Path $env:ProgramFiles 'Android'),
        (Join-Path ${env:ProgramFiles(x86)} 'Android'),
        (Join-Path $env:LOCALAPPDATA 'Programs')
    ) | Where-Object { $_ -and (Test-Path $_) }
    foreach ($root in $searchRoots) {
        $foundJava = Get-ChildItem -Path $root -Filter 'java.exe' -Recurse -ErrorAction SilentlyContinue |
            Where-Object { $_.FullName -match '\\jbr\\bin\\java\.exe$' } |
            Select-Object -First 1
        if ($foundJava) {
            $env:JAVA_HOME = Split-Path (Split-Path $foundJava.FullName -Parent) -Parent
            $env:Path = (Join-Path $env:JAVA_HOME 'bin') + ';' + $env:Path
            Info "Java ditemukan di: $env:JAVA_HOME"
            break
        }
    }
}
if (-not (Get-Command java.exe -ErrorAction SilentlyContinue)) {
    Fail 'Java tidak ditemukan. Instal Android Studio lengkap atau pasang Java 17, lalu jalankan skrip ini lagi.'
}

Info 'Menerima lisensi Android SDK...'
1..20 | ForEach-Object { 'y' } | & $SdkManager --sdk_root=$SdkRoot --licenses *> $null

Info 'Memasang emulator, platform-tools, dan image Google Play Android 35...'
& $SdkManager --sdk_root=$SdkRoot 'emulator' 'platform-tools' 'platforms;android-35' 'system-images;android-35;google_apis_playstore;x86_64'
if ($LASTEXITCODE -ne 0) { Fail 'Komponen SDK gagal dipasang.' }

$existing = & $AvdManager list avd 2>$null | Select-String "Name: $AvdName"
if (-not $existing) {
    Info 'Membuat perangkat virtual AndroidLite-Play...'
    "no" | & $AvdManager create avd --name $AvdName --package 'system-images;android-35;google_apis_playstore;x86_64' --device 'pixel_2' --force
    if ($LASTEXITCODE -ne 0) { Fail 'AVD gagal dibuat.' }
} else {
    Info 'AVD sudah ada; konfigurasi lama dipakai.'
}

$AvdConfig = Join-Path $env:USERPROFILE ".android\avd\$AvdName.avd\config.ini"
if (Test-Path $AvdConfig) {
    $cfg = Get-Content $AvdConfig
    $replacements = @{
        'hw.ramSize=' = 'hw.ramSize=3072'
        'hw.cpu.ncore=' = 'hw.cpu.ncore=2'
        'hw.lcd.width=' = 'hw.lcd.width=1280'
        'hw.lcd.height=' = 'hw.lcd.height=720'
        'hw.lcd.density=' = 'hw.lcd.density=320'
        'disk.dataPartition.size=' = 'disk.dataPartition.size=4294967296'
    }
    foreach ($key in $replacements.Keys) {
        $line = $replacements[$key]
        if ($cfg -match "^$([regex]::Escape($key))") { $cfg = $cfg -replace "^$([regex]::Escape($key)).*$", $line }
        else { $cfg += $line }
    }
    Set-Content -Path $AvdConfig -Value $cfg -Encoding ASCII
}

$launcher = Join-Path $PSScriptRoot 'Mulai-Emulator.bat'
@"
@echo off
set "SDK=%SdkRoot%"
"%SDK%\emulator\emulator.exe" -avd $AvdName -gpu auto -no-boot-anim -no-snapshot-load
"@ | Set-Content -Path $launcher -Encoding ASCII

$stopper = Join-Path $PSScriptRoot 'Matikan-Emulator.bat'
@"
@echo off
"$AdbExe" -s emulator-5554 emu kill
"@ | Set-Content -Path $stopper -Encoding ASCII

Info 'Selesai.'
Write-Host "Mulai: $launcher" -ForegroundColor Green
Write-Host "Matikan: $stopper" -ForegroundColor Green
Write-Host 'Catatan: aktifkan Intel VT-x/AMD-V/SVM di BIOS agar emulator lancar.' -ForegroundColor Yellow

if ($Start) { Start-Process -FilePath $launcher }
